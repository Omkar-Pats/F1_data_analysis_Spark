# Databricks notebook source
# MAGIC %md
# MAGIC ## Notebook Introduction
# MAGIC * UI Introduction
# MAGIC * Magic Commands

# COMMAND ----------

# DBTITLE 1,Below command is for Python
# MAGIC %python
# MAGIC msg = "Welcome to Databricks!!"

# COMMAND ----------

# MAGIC %python
# MAGIC print(msg)

# COMMAND ----------

# MAGIC %sql
# MAGIC select "Hello"

# COMMAND ----------

# MAGIC %scala
# MAGIC val msg = "hello world!!"

# COMMAND ----------

# MAGIC %r
# MAGIC 
# MAGIC x <- "Hello"
# MAGIC print(x)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/databricks-datasets/COVID/USAFacts/

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/databricks-datasets/COVID/USAFacts/covid_confirmed_usafacts.csv

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -latr
# MAGIC cd logs
# MAGIC ls -latr

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 