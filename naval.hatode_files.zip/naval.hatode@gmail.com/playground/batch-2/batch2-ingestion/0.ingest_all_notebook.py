# Databricks notebook source
circuit_file_sucess= dbutils.notebook.run("1.ingestion_circuits_csv", 0, {"user_input": "circuit_file"})

# COMMAND ----------

circuit_file_sucess

# COMMAND ----------

races_file_sucess= dbutils.notebook.run("2.ingest_races_file", 0, {"user_input": "races_file"})

# COMMAND ----------

races_file_sucess

# COMMAND ----------

constructor_file_sucess= dbutils.notebook.run("3.Ingest_constructor_json", 0, {"user_input": "constructor_file"})

# COMMAND ----------

constructor_file_sucess

# COMMAND ----------

driver_file_sucess= dbutils.notebook.run("4.ingest_driver_json_nested", 0, {"user_input": "driver_file"})

# COMMAND ----------

driver_file_sucess

# COMMAND ----------

pitstop_file_sucess= dbutils.notebook.run("5.ingest_pit_stop_multiline", 0, {"user_input": "pitstop_file"})

# COMMAND ----------

pitstop_file_sucess

# COMMAND ----------

qualifying_file_sucess= dbutils.notebook.run("6.ingest_qualifying_multiline", 0, {"user_input": "qualifying"})

# COMMAND ----------

qualifying_file_sucess

# COMMAND ----------

laptimeg_file_sucess= dbutils.notebook.run("7.ingest_laptime_multiple_csv", 0, {"user_input": "laptime_file"})

# COMMAND ----------

laptime_file_sucess

# COMMAND ----------

results_file_sucess= dbutils.notebook.run("8.ingest_results_json", 0, {"user_input": "results_file"})

# COMMAND ----------

results_file_sucess