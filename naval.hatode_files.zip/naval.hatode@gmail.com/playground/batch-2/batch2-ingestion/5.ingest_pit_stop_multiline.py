# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import * 

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

pitstop_schema = StructType( fields = [StructField("raceId",IntegerType(),False),
                                      StructField("driverId",IntegerType(),True),
                                      StructField("stop",IntegerType(),True),
                                      StructField("lap",IntegerType(),True),
                                      StructField("time",StringType(),True),
                                      StructField("duration",StringType(),True),
                                      StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

pitstop_df = spark.read.option("header",True).schema(pitstop_schema).option("multiline",True).json(f"{raw_folder_path}/pit_stops.json")

# COMMAND ----------

display(pitstop_df)

# COMMAND ----------

pitstop_renamed_df = pitstop_df.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id")

# COMMAND ----------

pitstop_fianl_df = add_ingestion_date(pitstop_renamed_df)

# COMMAND ----------

pitstop_fianl_df.write.mode("overwrite").parquet(f"{processed_folder_path}/pit_stops")