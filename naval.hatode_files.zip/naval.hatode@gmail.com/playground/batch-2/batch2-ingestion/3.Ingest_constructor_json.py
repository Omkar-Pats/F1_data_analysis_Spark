# Databricks notebook source
# MAGIC %md
# MAGIC ### Read Json file 

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import * 

# COMMAND ----------

dbutils.widgets.text("input_parameter","")
user_inputed_value = dbutils.widgets.get("input_parameter")

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

## created own schema

constructor_scheam = StructType(fields = [StructField("constructorId",IntegerType(),False),
                                         StructField("constructorRef",StringType(),False),
                                         StructField("name",StringType(),False),
                                         StructField("nationality",StringType(),False),
                                         StructField("url",StringType(),False)
                                       ]) 

# COMMAND ----------

## created datafram

constructor_df = spark.read \
.option("header",True) \
.schema(constructor_scheam) \
.json(f'{raw_folder_path}/constructors.json')

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformation
# MAGIC * Renamed the columns
# MAGIC * dropped url column

# COMMAND ----------

constructor_renamed_df = constructor_df.withColumnRenamed("constructorId","constructor_id") \
.withColumnRenamed("constructorRef","constructor_ref") \
.withColumn("environment", lit(user_inputed_value)) \
.drop("url")

# COMMAND ----------

constructor_final_df = add_ingestion_date(constructor_renamed_df)

# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").parquet(f'{processed_folder_path}/constructors')

# COMMAND ----------

display(spark.read.parquet(f'{processed_folder_path}/constructors'))