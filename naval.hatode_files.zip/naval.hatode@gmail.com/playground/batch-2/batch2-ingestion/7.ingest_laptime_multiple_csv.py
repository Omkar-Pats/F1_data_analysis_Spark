# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths/"

# COMMAND ----------

laptime_schema = StructType (fields = [StructField("raceId",IntegerType(),False),
                                     StructField("driverId",IntegerType(),False),
                                     StructField("lap",IntegerType(),False),
                                     StructField("position",IntegerType(),False),
                                     StructField("time",StringType(),False),
                                     StructField("milliseconds",IntegerType(),False)])

# COMMAND ----------

laptime_df = spark.read \
.option("header",True) \
.schema(laptime_schema) \
.csv(f"{raw_folder_path}/lap_times/lap_time*")

# COMMAND ----------

laptime_remaned_df = laptime_df.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id")

# COMMAND ----------

laptime_final_df = add_ingestion_date(laptime_remaned_df)

# COMMAND ----------

laptime_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/laptime")

# COMMAND ----------

