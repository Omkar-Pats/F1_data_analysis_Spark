# Databricks notebook source
# MAGIC %md
# MAGIC ### Read Json file 

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import * 

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

name_schema = StructType(fields = [StructField("forename",StringType(),True),
                                   StructField("surname",StringType(),True)]) 

# COMMAND ----------

## created own schema

driver_scheam = StructType(fields = [StructField("driverId",IntegerType(),False),
                                         StructField("driverRef",StringType(),True),
                                         StructField("number",IntegerType(),True),
                                         StructField("code",StringType(),True),
                                         StructField("name",name_schema,True),
                                          StructField("dob",StringType(),True),
                                          StructField("nationality",StringType(),True),
                                          StructField("url",StringType(),True)
                                       ]) 

# COMMAND ----------

## created datafram

driver_df = spark.read \
.option("header",True) \
.schema(driver_scheam) \
.json(f'{raw_folder_path}/drivers.json')

# COMMAND ----------

display(driver_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformation
# MAGIC * Renamed the columns
# MAGIC * dropped url column

# COMMAND ----------

driver_renamed_df = driver_df.withColumnRenamed("driverId","driver_id") \
.withColumnRenamed("driverRef","driver_ref") \
.drop("url")

# COMMAND ----------

driver_concat_df = driver_renamed_df.withColumn("full_name",concat(col("name.forename"), lit(" "), col("name.surname"))) \
.drop("name")

# COMMAND ----------

display(driver_concat_df)

# COMMAND ----------

dirver_final_df = add_ingestion_date(driver_concat_df)

# COMMAND ----------

dirver_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/drivers")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/drivers"))