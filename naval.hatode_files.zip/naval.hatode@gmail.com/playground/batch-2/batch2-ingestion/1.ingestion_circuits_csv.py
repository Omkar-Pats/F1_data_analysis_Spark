# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest CSV in dataframe

# COMMAND ----------

circuits_df = spark.read.option("header",True).option("inferSchema",True).csv('/mnt/formula01dl/raw/circuits.csv')

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("input_parameter", "")
user_input_value =dbutils.widgets.get("input_parameter")

# COMMAND ----------

user_input_value

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define own Schema

# COMMAND ----------

circuits_schema = StructType(fields = [StructField("circuitId",IntegerType(),False),
                                      StructField("circuitRef",StringType(),True),
                                      StructField("name",StringType(),True),
                                      StructField("location",StringType(),True),
                                      StructField("country",StringType(),True),
                                      StructField("lat",DoubleType(),True),
                                      StructField("lng",DoubleType(),True),
                                      StructField("alt",DoubleType(),True),
                                      StructField("url",StringType(),True)])

# COMMAND ----------

circuits_schema = 'circuitId INT, circuitRef STRING , name STRING, location STRING, country STRING , lat DOUBLE, lng DOUBLE, alt INT ,url STRING'

# COMMAND ----------

circuit_df = spark.read \
.option('header',True) \
.schema(circuits_schema) \
.csv(f'{raw_folder_path}/circuits.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Column Selection & Droping columns
# MAGIC * 4 ways we can select the columns from a dataframe
# MAGIC * Droping specific column from Dataframe

# COMMAND ----------

display(circuit_df)

# COMMAND ----------

circuit_selected_df = circuit_df.select("circuitId","circuitRef",'name','location','country','lat','lng','alt')

# COMMAND ----------

circuit_selected_df= circuit_df.drop('url','alt')

# COMMAND ----------

circuit_selected_df= circuit_df.select(circuit_df.circuitId.alias('circuit_id'),
                                       circuit_df.circuitRef,
                                       circuit_df.name,
                                       circuit_df.location,
                                       circuit_df.country,
                                       circuit_df.lat,
                                       circuit_df.lng,
                                       circuit_df.alt)

# COMMAND ----------

circuit_selected_df= circuit_df.select(circuit_df["circuitId"],
                                       circuit_df["circuitRef"],
                                       circuit_df["name"],
                                       circuit_df["location"],
                                       circuit_df["country"],
                                       circuit_df["lat"],
                                       circuit_df["lng"],
                                       circuit_df["alt"])

# COMMAND ----------

from pyspark.sql.functions import col , lit 

# COMMAND ----------

circuit_selected_df = circuit_df.select(col("circuitId"),
                                                 col("circuitRef"), 
                                                 col("name"),
                                                 col("location"),
                                                 col("country"),
                                                 col("lat"),
                                                 col("lng"),
                                                 col("alt"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation commands
# MAGIC * Renaming the column from Dataframe
# MAGIC * Adding the column to the dataframe

# COMMAND ----------

circuit_renamed_df = circuit_selected_df.withColumnRenamed("circuitId","circuit_id") \
.withColumnRenamed("circuitRef","circuit_ref") \
.withColumnRenamed("lat","latitude") \
.withColumnRenamed("lng","longititude") \
.withColumnRenamed("alt","altitude") \
.withColumn("environment", lit(user_input_value))


# COMMAND ----------

display(circuit_renamed_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

circuit_final_df = add_ingestion_date(circuit_renamed_df)

# COMMAND ----------

display(circuit_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write the dataframe in data lake gen 2 

# COMMAND ----------

circuit_final_df.write.mode("overwrite").parquet(f'{processed_folder_path}/circuits/')

# COMMAND ----------

# DBTITLE 0,Read parquet file
display(spark.read.parquet(f'{processed_folder_path}/circuits/'))

# COMMAND ----------

dbutils.notebook.exit("Succefully Completed!!")