# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import * 

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

# MAGIC %run "../includes-batch2/comman_functions"

# COMMAND ----------

qualifying_df = spark.read \
.option("header",True) \
.option("inferSchema",True)\
.option("multiline",True) \
.json(f"{raw_folder_path}/qualifying/qualifying*.json")

# COMMAND ----------

display(qualifying_df)

# COMMAND ----------

qualifying_renamed_df = qualifying_df.withColumnRenamed("constructorId","constructor_id") \
.withColumnRenamed("driverId","driver_id")

# COMMAND ----------

qualifying_final_df = add_ingestion_date(qualifying_renamed_df)

# COMMAND ----------

qualifying_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/qualifying")

# COMMAND ----------

