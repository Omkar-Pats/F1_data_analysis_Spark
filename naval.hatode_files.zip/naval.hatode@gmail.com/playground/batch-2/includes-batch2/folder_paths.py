# Databricks notebook source
raw_folder_path = '/mnt/formula01dl/raw/'
processed_folder_path = '/mnt/formula01dl/processed/batch-2'
presentation_folder_path = '/mnt/formula01dl/presentation/batch-2'

# COMMAND ----------

