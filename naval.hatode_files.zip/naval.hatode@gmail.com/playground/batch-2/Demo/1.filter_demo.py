# Databricks notebook source
# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

# filter command sql way

#isplay(races_df.where("race_year = 2019 and circuit_Id <50"))
display(races_df.where("name = 'Chinese Grand Prix'"))

# COMMAND ----------

## python command to do filter method

filter_df = races_df.filter((races_df.race_year == 2019) & (races_df.circuit_Id < 50))

# COMMAND ----------

display(filter_df)

# COMMAND ----------

