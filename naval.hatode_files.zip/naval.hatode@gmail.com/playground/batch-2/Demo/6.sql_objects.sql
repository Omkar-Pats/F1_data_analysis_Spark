-- Databricks notebook source
select * from global_temp.gv_race_results;

-- COMMAND ----------

create database if not exists batch2;

-- COMMAND ----------

show databases;

-- COMMAND ----------

desc database extended batch2;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

use batch2;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Managed Table
-- MAGIC * Create managed table using python
-- MAGIC * Create managed table using sql
-- MAGIC * effect of Droping Managed table
-- MAGIC * describe table

-- COMMAND ----------

-- MAGIC %run "../includes-batch2/folder_paths"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df= spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("batch2.race_results_py")

-- COMMAND ----------

select * from batch2.race_results_py where race_name like '%Australian%';

-- COMMAND ----------

show tables in batch2;

-- COMMAND ----------

describe table extended batch2.race_results_py;

-- COMMAND ----------

create table batch2.race_results_sql
as 
select * from batch2.race_results_py;

-- COMMAND ----------

select * from batch2.race_results_sql where race_year = 2020

-- COMMAND ----------

drop table batch2.race_results_sql;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### External Table
-- MAGIC * Create External table using python
-- MAGIC * Create External table using sql
-- MAGIC * effect of Droping External table
-- MAGIC * describe table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py").saveAsTable("batch2.race_results_ext_py")

-- COMMAND ----------

select * from batch2.race_results_ext_py;

-- COMMAND ----------

desc table extended batch2.race_results_ext_py

-- COMMAND ----------

drop table if exists batch2.race_results_ext_sql;

create table if not exists batch2.race_results_ext_sql
(
race_year int,
race_name String,
race_date timestamp,
circuit_location string,
driver_name string,
driver_number int,
driver_nationality string,
team string,
grid int,
fastest_lap string,
race_time string,
points float,
position string,
create_date timestamp
)
using parquet
location "/mnt/formula01dl/presentation/batch-2/race_results_ext_sql"

-- COMMAND ----------

desc table extended batch2.race_results_ext_sql

-- COMMAND ----------

insert into batch2.race_results_ext_sql
select * from batch2.race_results_ext_py;

-- COMMAND ----------

drop table batch2.race_results_ext_sql;

-- COMMAND ----------

select * from batch2.race_results_ext_sql;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC reace_df = spark.read.parquet("/mnt/formula01dl/presentation/batch-2/race_results_ext_sql")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(reace_df)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 
-- MAGIC #### View table using sql 
-- MAGIC * temp View using SQL
-- MAGIC * Global View using SQL
-- MAGIC * Permanent View using SQL

-- COMMAND ----------

---- Temp View ---- 
create or replace temp view tv_race_results
as 
select * from batch2.race_results_ext_py where race_year = 2000


-- COMMAND ----------

select * from tv_race_results

-- COMMAND ----------

show tables in global_temp

-- COMMAND ----------

---- Global View ---- 
create or replace global temp view gv_race_results
as 
select * from batch2.race_results_ext_py where race_year = 2010

-- COMMAND ----------

select * from global_temp.gv_race_results;

-- COMMAND ----------

---- Permanent View ---- 
create or replace view batch2.pv_race_results
as 
select * from batch2.race_results_ext_py where race_year = 2011

-- COMMAND ----------

show tables in batch2

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 
-- MAGIC ### Create table using csv

-- COMMAND ----------

drop table if exists batch2.ciruits_sql;

create table if not exists batch2.ciruits_sql(
circuitId int,
circuitRef string,
name string,
location string,
country string,
lat float,
lng float,
alt float,
url string
)
using csv
options(path "/mnt/formula01dl/raw/circuits.csv", header true)

-- COMMAND ----------

select * from batch2.ciruits_sql;

-- COMMAND ----------

