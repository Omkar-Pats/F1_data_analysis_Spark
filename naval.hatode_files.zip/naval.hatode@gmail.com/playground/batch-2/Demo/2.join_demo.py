# Databricks notebook source
# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits")
races_df = spark.read.parquet(f"{processed_folder_path}/races").filter("race_year = 2019")

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

display(races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Inner Join
# MAGIC 
# MAGIC #### New_DF = left_side_df.join(right_side_df,condition,type_of_join)

# COMMAND ----------

new_df = circuits_df.join(races_df,circuits_df.circuit_id == races_df.circuit_Id,"inner")

# COMMAND ----------

display(new_df)

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ###### left outer join

# COMMAND ----------

new_df = circuits_df.join(races_df,circuits_df.circuit_id == races_df.circuit_Id,"left") \
.select(circuits_df.circuit_id,circuits_df.name,circuits_df.location,races_df.name,races_df.race_year)

# COMMAND ----------

display(new_df)

# COMMAND ----------

new_df = circuits_df.join(races_df,circuits_df.circuit_id == races_df.circuit_Id,"right") \
.select(circuits_df.circuit_id,circuits_df.name,circuits_df.location,races_df.name,races_df.race_year)

# COMMAND ----------

display(new_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC 
# MAGIC ##### cross join --> It will provide cartesian product 

# COMMAND ----------

new_df = circuits_df.crossJoin(races_df)

# COMMAND ----------

display(new_df)

# COMMAND ----------

new_df.count()

# COMMAND ----------

int(circuits_df.count() * races_df.count())

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Join
# MAGIC * Full Outer Join
# MAGIC * semi Join
# MAGIC * anti Join

# COMMAND ----------

