# Databricks notebook source
# MAGIC %md
# MAGIC ## Aggregation commands 
# MAGIC * count
# MAGIC * countDistinct
# MAGIC * sum
# MAGIC * groupBy with agg()

# COMMAND ----------

# MAGIC %run "../includes-batch2/folder_paths"

# COMMAND ----------

## read the datafram from presentation layer
race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")


# COMMAND ----------

display(race_results_df)


# COMMAND ----------

race_agg_df = race_results_df.where("race_year = 2020")

# COMMAND ----------

## count aggregate Function

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum

# COMMAND ----------

race_results_df.count()

# COMMAND ----------

demo = race_agg_df.select(count("*").alias ("count_of_rows"))

# COMMAND ----------

## countDistinct aggregate Function

# COMMAND ----------

race_agg_df.select(countDistinct("race_name").alias ("count_of_distinct_race")).show()

# COMMAND ----------

## sum aggregate Function

# COMMAND ----------

race_agg_df.select(sum("points").alias ("sum_of_points")).show()

# COMMAND ----------

race_agg_df.where("driver_name = 'Lewis Hamilton'") \
.select(sum("points").alias ("total_points"),countDistinct("race_name").alias ("count_of_distinct_race")) \
.show()

# COMMAND ----------

## group aggregation

# COMMAND ----------

race_agg_df.groupBy("driver_name") \
.agg(sum("points").alias ("total_points"),count("race_name").alias ("number_of_race")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Window functions
# MAGIC 
# MAGIC * rank()
# MAGIC * dense_rank()

# COMMAND ----------

## "widnow Specification" that defines which rows are included in a window(frame)

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

race_results_win_df = spark.read.parquet(f"{presentation_folder_path}/race_results").filter("race_year in (2019,2020)")

# COMMAND ----------

display(race_results_win_df)

# COMMAND ----------

demo= race_results_win_df \
.groupBy("driver_name","race_year") \
.agg(sum("points").alias ("total_points"),count("race_name").alias ("number_of_race"))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc, rank, dense_rank

# COMMAND ----------

driver_rankSpe = Window.partitionBy("race_year").orderBy(desc("total_points"))
wind_final_df= demo.withColumn("rank",rank().over(driver_rankSpe))

# COMMAND ----------

display(wind_final_df)

# COMMAND ----------

driver_rankSpe = Window.partitionBy("race_year").orderBy(desc("total_points"))
wind_final_df= demo.withColumn("rank",dense_rank().over(driver_rankSpe))

# COMMAND ----------

display(wind_final_df)

# COMMAND ----------

