# Databricks notebook source
# MAGIC %md
# MAGIC # 1) File storage utility

# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.ls('/databricks-datasets/')

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %md
# MAGIC #2) Notebook utility command

# COMMAND ----------

dbutils.notebook.help()

# COMMAND ----------

dbutils.notebook.help("run")

# COMMAND ----------

dbutils.notebook.run('./child_notebook',100)

# COMMAND ----------

# MAGIC %md
# MAGIC #3) widget utility command

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("input","", "Pass the value")

# COMMAND ----------

print(dbutils.widgets.get("input"))

# COMMAND ----------

dbutils.widgets.dropdown("Products","Iphone",("Iphone","Iphone10","Iphone11","Iphone12"))


# COMMAND ----------

print(dbutils.widgets.get("Products"))

# COMMAND ----------

dbutils.widgets.remove("input")

# COMMAND ----------

# MAGIC %md
# MAGIC #4) Secrete Utility

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # 5) Libarary utility

# COMMAND ----------

dbutils.library.help()

# COMMAND ----------

# MAGIC %pip install pandas

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula01dl/raw

# COMMAND ----------

circuits_df =spark.read.option("header", True).csv("dbfs:/mnt/formula01dl/raw/circuits.csv")

# COMMAND ----------

type(circuits_df)

# COMMAND ----------

display(circuits_df)