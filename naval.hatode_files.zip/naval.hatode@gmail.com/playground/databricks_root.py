# Databricks notebook source


# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

# MAGIC %fs 
# MAGIC ls dbfs:/databricks-results/

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Select * from default.circuits