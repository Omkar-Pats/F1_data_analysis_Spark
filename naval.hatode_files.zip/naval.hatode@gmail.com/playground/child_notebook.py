# Databricks notebook source
print("I am in child Notebook!!")

# COMMAND ----------

dbutils.notebook.exit('exited')