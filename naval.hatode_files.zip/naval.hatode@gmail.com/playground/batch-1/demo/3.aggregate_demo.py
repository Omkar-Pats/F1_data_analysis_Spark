# Databricks notebook source
# MAGIC %run "../includes/folder_path"

# COMMAND ----------

results_df = spark.read.parquet (f"{presentation_folder_path}/race_results")

# COMMAND ----------

display(results_df)

# COMMAND ----------

agregate_df = results_df.where("race_year = 2020")

# COMMAND ----------

display(agregate_df)

# COMMAND ----------

## count , countDistinct , sum 

# COMMAND ----------

from pyspark.sql.functions import count , countDistinct , sum 

# COMMAND ----------

agregate_df.select(count("race_year")).show()

# COMMAND ----------

agregate_df.select(countDistinct("race_name")).show()

# COMMAND ----------

display(agregate_df.select(sum("points")))

# COMMAND ----------

agregate_df.where("driver_name = 'Lewis Hamilton'").select(sum("points"),countDistinct("race_name")) \
.withColumnRenamed("sum(points)", "total_points") \
.withColumnRenamed("count(DISTINCT race_name)", "number_of_races") \
.show()

# COMMAND ----------

agregate_df.where("driver_name = 'Valtteri Bottas'").select(sum("points"),countDistinct("race_name")) \
.withColumnRenamed("sum(points)", "total_points") \
.withColumnRenamed("count(DISTINCT race_name)", "number_of_races") \
.show()

# COMMAND ----------

agregate_df.groupBy("driver_name") \
.agg(sum("points"),countDistinct("race_name")) \
.withColumnRenamed("sum(points)", "total_points") \
.withColumnRenamed("count(race_name)", "number_of_races") \
.show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Windows function 

# COMMAND ----------

results_df = spark.read.parquet (f"{presentation_folder_path}/race_results").filter("race_year in(2019,2020)")

# COMMAND ----------

display(results_df)

# COMMAND ----------

from pyspark.sql.functions import sum, countDistinct

# COMMAND ----------

results_agg_df = results_df.groupBy("race_year", "driver_name") \
.agg(sum("points"),countDistinct("race_name")) \
.withColumnRenamed("sum(points)", "total_points") \
.withColumnRenamed("count(race_name)", "number_of_races")

# COMMAND ----------

display(results_agg_df)

# COMMAND ----------

from pyspark.sql.functions import desc, rank, dense_rank

# COMMAND ----------

from pyspark.sql.window import Window

driver_rank_spec = Window.partitionBy("race_year").orderBy(desc("total_points"))
rank_window_df = results_agg_df.withColumn("rank",rank().over(driver_rank_spec))

# COMMAND ----------

display(rank_window_df)

# COMMAND ----------

from pyspark.sql.window import Window

driver_dense_rank_spec = Window.partitionBy("race_year").orderBy(desc("total_points"))
dense_rank_window_df = results_agg_df.withColumn("rank",dense_rank().over(driver_rank_spec))

# COMMAND ----------

display(dense_rank_window_df)

# COMMAND ----------

