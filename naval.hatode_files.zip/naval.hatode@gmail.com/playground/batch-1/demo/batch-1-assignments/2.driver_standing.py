# Databricks notebook source
# MAGIC %run "../../includes/folder_path"

# COMMAND ----------

driver_standing_df = spark.read.parquet (f"{presentation_folder_path}/race_results")

# COMMAND ----------

display(driver_standing_df)

# COMMAND ----------

from pyspark.sql.functions import sum, count,when, col

# COMMAND ----------

driver_standing_new_df = driver_standing_df \
.groupBy("race_year","driver_name","driver_nationality","team") \
.agg(count(when(col("position")== 1,True)).alias ("wins"),
    sum("points").alias ("total_no_points"))

# COMMAND ----------

display(driver_standing_new_df.where("race_year=2020"))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank,desc

# COMMAND ----------

driver_spec = Window.partitionBy("race_year").orderBy(desc("total_no_points"),desc("wins"))
driver_final_df = driver_standing_new_df.withColumn("rank",rank().over(driver_spec))

# COMMAND ----------

display(driver_final_df.where("race_year=2020"))

# COMMAND ----------

driver_final_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/driver_standing")

# COMMAND ----------

