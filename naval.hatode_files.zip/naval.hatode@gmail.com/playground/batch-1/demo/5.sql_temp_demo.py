# Databricks notebook source
# MAGIC %md
# MAGIC ### Local temporary View
# MAGIC * Create Local Temp View 
# MAGIC * Access the Local Temp View in SQL Cell
# MAGIC * Access the Local Temp View in python Cell
# MAGIC * Can not access from another Notebook

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

race_result_df = spark.read.parquet (f"{presentation_folder_path}/race_results")

# COMMAND ----------

race_result_df.createTempView("tv_race_result")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tv_race_result where race_year = 2020

# COMMAND ----------

dbutils.widgets.text("p_race_year","")
v_race_year= dbutils.widgets.get("p_race_year")

# COMMAND ----------

display(spark.sql(f"select * from tv_race_result where race_year = {v_race_year}"))

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC show views from global_temp;

# COMMAND ----------

