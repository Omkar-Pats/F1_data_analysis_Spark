-- Databricks notebook source
-- MAGIC %md
-- MAGIC 
-- MAGIC ### Lesson Objective
-- MAGIC * Spark Documentation
-- MAGIC * Create database demo
-- MAGIC * Data tab in the UI
-- MAGIC * SHOW Command
-- MAGIC * DESCRIBE Command
-- MAGIC * Find the current Database

-- COMMAND ----------

create database naval;

-- COMMAND ----------

create database if not exists naval;

-- COMMAND ----------

show databases;

-- COMMAND ----------

describe database extended naval;

-- COMMAND ----------

select current_database()

-- COMMAND ----------

use naval;

-- COMMAND ----------

show tables in default

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 
-- MAGIC ### Managed Table
-- MAGIC * Spark Documentation
-- MAGIC * Create managed table by sql
-- MAGIC * Create managed table by python
-- MAGIC * effect of dropping managed table 
-- MAGIC * DESCRIBE table

-- COMMAND ----------

-- MAGIC %run "../includes/folder_path"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results.write.format("parquet").saveAsTable("naval.race_results_py")

-- COMMAND ----------

select * from naval.race_results_py where race_year = 2018

-- COMMAND ----------

show tables in naval;

-- COMMAND ----------

desc table extended race_results_sql;

-- COMMAND ----------

create table naval.race_results_sql
as 
select * from naval.race_results_py where race_year = 2018

-- COMMAND ----------

drop table naval.race_results_sql

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 
-- MAGIC ### External Table
-- MAGIC * Spark Documentation
-- MAGIC * Create External table by sql
-- MAGIC * Create External table by python
-- MAGIC * effect of dropping External table 
-- MAGIC * DESCRIBE table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results.write.format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py").saveAsTable("naval.race_results_ext_py")

-- COMMAND ----------

describe table extended race_results_ext_py;

-- COMMAND ----------

drop table if exists naval.race_results_ext_sql;

create table if not exists naval.race_results_ext_sql(
race_year int,
race_name string,
race_date timestamp,
circuit_location string,
driver_name string,
driver_number int,
driver_nationality string,
team string,
grid int,
fastest_lap string,
race_time string,
points float,
position string,
create_date timestamp
)
using parquet
location "/mnt/formula01dl/presentation/batch-1/race_results_ext_sql"

-- COMMAND ----------

insert into naval.race_results_ext_sql
select * from naval.race_results_ext_py where race_year = 2020;

-- COMMAND ----------

drop table naval.race_results_ext_sql;

-- COMMAND ----------



-- COMMAND ----------

-- MAGIC %md
-- MAGIC 
-- MAGIC ### Views Table
-- MAGIC * Spark Documentation
-- MAGIC * Create Temp view
-- MAGIC * Create Global View
-- MAGIC * Create Permanent View

-- COMMAND ----------

---TEMPORARY VIEW----

create or replace temp view tv_race_results
as 
select * from naval.race_results_ext_py where race_year = 2020


-- COMMAND ----------

select * from tv_race_results;

--show views;

-- COMMAND ----------

--- GLOBAL VIEW----

create or replace global temp view gv_race_results
as 
select * from naval.race_results_ext_py where race_year = 2019


-- COMMAND ----------

--select * from global_temp.gv_race_results;

show views in global_temp

-- COMMAND ----------

-- PERMANENT VIEW ---

create or replace view naval.pv_race_result
as 
select * from naval.race_results_ext_py where race_year = 2019

-- COMMAND ----------

