# Databricks notebook source
# MAGIC %run "../includes/folder_path"

# COMMAND ----------

circuit_df = spark.read.parquet(f"{processed_folder_path}/circuits")
race_df = spark.read.parquet(f"{processed_folder_path}/races").filter("race_year = 2019")

# COMMAND ----------

display(circuit_df)

# COMMAND ----------

display(race_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Inner Join
# MAGIC 
# MAGIC ** New_df = DF1.join(DF2, "<Condition>","<type of Join>")

# COMMAND ----------

circuits_races_df = circuit_df.join(race_df, circuit_df.circuit_id == race_df.circuit_Id,"inner") \
.select(circuit_df.circuit_id ,circuit_df.name,circuit_df.location ) \
.filter(race_df.circuit_Id < 30 )

# COMMAND ----------

display(circuits_races_df)

# COMMAND ----------

### Left outer Join

# COMMAND ----------

circuits_races_df = circuit_df.join(race_df, circuit_df.circuit_id == race_df.circuit_Id,"left") \
.select(circuit_df.circuit_id ,circuit_df.name,circuit_df.location, race_df.name,race_df.round)

# COMMAND ----------

display(circuits_races_df)

# COMMAND ----------

### right Outer Join

# COMMAND ----------

circuits_races_df = circuit_df.join(race_df, circuit_df.circuit_id == race_df.circuit_Id,"right") \
.select(circuit_df.circuit_id ,circuit_df.name,circuit_df.location, race_df.name,race_df.round)

# COMMAND ----------

display(circuits_races_df)

# COMMAND ----------

circuits_races_df = circuit_df.join(race_df, circuit_df.circuit_id == race_df.circuit_Id,"full") \
.select(circuit_df.circuit_id ,circuit_df.name,circuit_df.location, race_df.name,race_df.round)

# COMMAND ----------

display(circuits_races_df)

# COMMAND ----------

### cross Join

new_df = DF1.crossJoin(DF2)

# COMMAND ----------

circuits_races_df = circuit_df.crossJoin(race_df)

# COMMAND ----------

display(circuits_races_df)

# COMMAND ----------

circuits_races_df.count()

# COMMAND ----------

int(circuit_df.count() * race_df.count() )