# Databricks notebook source
# MAGIC %md
# MAGIC ### read Json file

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

constructor_schema = "constructorId INT , constructorRef STRING, name STRING, nationality STRING, url STRING"

# COMMAND ----------

constructor_df = spark.read \
.option('header',True) \
.schema(constructor_schema) \
.json(f'{raw_folder_path}/constructors.json')

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

constructor_renamed_df = constructor_df.withColumnRenamed("constructorId","constructor_id") \
.withColumnRenamed("constructorRef","constructor_ref") \
.withColumn("environment", lit(user_output_variable)) \
.drop("url")

# COMMAND ----------

constructor_final_df = ingestion_date_column(constructor_renamed_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/constructor/")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/constructor/"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")