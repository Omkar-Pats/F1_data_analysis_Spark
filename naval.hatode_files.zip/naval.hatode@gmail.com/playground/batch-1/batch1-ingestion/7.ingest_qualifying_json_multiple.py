# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

qualifying_df = spark.read \
.option("header",True) \
.option("inferSchema",True) \
.option("multiline",True) \
.json(f"{raw_folder_path}/qualifying/qualifying*")

# COMMAND ----------

display(qualifying_df)

# COMMAND ----------

qualifing_renamed_df = qualifying_df.withColumnRenamed("constructorId","constructor_id") \
.withColumnRenamed("driverId","driver_id") \
.withColumnRenamed("qualifyId","qualify_id") \
.withColumnRenamed("raceId","race_id") \
.withColumn("environment" , lit(user_output_variable))

# COMMAND ----------

qualifing_final_df = ingestion_date_column(qualifing_renamed_df)

# COMMAND ----------

qualifing_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/qualifying")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/qualifying"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")