# Databricks notebook source
# MAGIC %md
# MAGIC #### Ingest circuits CSV & perform transformation 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField,IntegerType, StringType, DoubleType
from pyspark.sql.functions import lit

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

circuit_schema = StructType(fields = [StructField("circuitId",IntegerType(),False),
                                     StructField("circuitRef",StringType(),True),
                                     StructField("name",StringType(),True),
                                     StructField("location",StringType(),True),
                                     StructField("country",StringType(),True),
                                     StructField("lat",DoubleType(),True),
                                     StructField("lng",DoubleType(),True),
                                     StructField("alt",DoubleType(),True),
                                     StructField("url",StringType(),True)])

# COMMAND ----------

circuit_df = spark.read \
.option('header',True) \
.schema(circuit_schema) \
.csv(f"{raw_folder_path}/circuits.csv")

# COMMAND ----------

circuit_selected_df = circuit_df.select("circuitId","circuitRef","name","location","country","lat","lng","alt")

# COMMAND ----------

circuit_selected_df= circuit_df.drop("url")

# COMMAND ----------

circuit_selected_df = circuit_selected_df.select(circuit_selected_df.circuitId,
                                                 circuit_selected_df.circuitRef, 
                                                 circuit_selected_df.name,
                                                 circuit_selected_df.location,
                                                 circuit_selected_df.country,
                                                 circuit_selected_df.lat,
                                                 circuit_selected_df.lng,
                                                 circuit_selected_df.alt)

# COMMAND ----------

circuit_selected_df = circuit_selected_df.select(circuit_selected_df["circuitId"],
                                                 circuit_selected_df["circuitRef"], 
                                                 circuit_selected_df["name"],
                                                 circuit_selected_df["location"],
                                                 circuit_selected_df["country"],
                                                 circuit_selected_df["lat"],
                                                 circuit_selected_df["lng"],
                                                 circuit_selected_df["alt"])

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

circuit_selected_df = circuit_selected_df.select(col("circuitId"),
                                                 col("circuitRef"), 
                                                 col("name"),
                                                 col("location"),
                                                 col("country"),
                                                 col("lat"),
                                                 col("lng"),
                                                 col("alt"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformation Commands
# MAGIC * Rename the columns
# MAGIC * Add the columns

# COMMAND ----------

circuits_renamed_df = circuit_selected_df.withColumnRenamed("circuitId","circuit_id") \
.withColumnRenamed("circuitRef","circuit_ref") \
.withColumnRenamed("lat","latitude") \
.withColumnRenamed("lng","longitude") \
.withColumnRenamed("alt","altitude") \
.withColumn("Environment",lit(user_output_variable))

# COMMAND ----------

display(circuits_renamed_df)

# COMMAND ----------

circuits_final_df = ingestion_date_column(circuits_renamed_df)
                                                  

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### write the dataframe in delta lake /processed folder in parquet format

# COMMAND ----------

circuits_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/circuits/")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/circuits/"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")