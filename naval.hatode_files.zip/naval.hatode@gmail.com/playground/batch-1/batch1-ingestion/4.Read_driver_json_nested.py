# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import concat , lit, current_timestamp,col

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

name_schema = StructType(fields =[StructField ("forename", StringType(),True),
                                 StructField ("surname", StringType(),True)])

# COMMAND ----------

drivers_schema = StructType(fields =[StructField ("driverId", IntegerType(),False),
                                     StructField ("driverRef", StringType(),True),
                                     StructField ("number", IntegerType(),True),
                                    StructField ("code", StringType(),True),
                                    StructField ("name", name_schema,True),
                                    StructField ("dob", StringType(),True),
                                    StructField ("nationality", StringType(),True),
                                    StructField ("url", StringType(),True)])

# COMMAND ----------

drivers_df = spark.read \
.option('header',True) \
.schema(drivers_schema) \
.json(f"{raw_folder_path}/drivers.json")

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

drivers_renamed_df = drivers_df.withColumnRenamed("driverId","driver_id") \
.withColumnRenamed("driverRef","driver_ref") \
.withColumn("full_name", concat(col("name.forename"), lit(" "), col("name.surname"))) \
.withColumn("environment", lit(user_output_variable)) \
.drop("url","name")
## Lewis Hamilton

# COMMAND ----------

drivers_final_df= ingestion_date_column(drivers_renamed_df)

# COMMAND ----------

display(drivers_final_df)

# COMMAND ----------

drivers_final_df.write.mode('overwrite').parquet(f"{processed_folder_path}/drivers/")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/drivers/"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")