# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

pit_stop_schema = StructType(fields =[StructField ("raceId", IntegerType(),False),
                                     StructField ("driverId", IntegerType(),True),
                                     StructField ("stop", IntegerType(),True),
                                    StructField ("lap", IntegerType(),True),
                                    StructField ("time", StringType(),True),
                                    StructField ("duration", StringType(),True),
                                    StructField ("milliseconds", StringType(),True)
                                   ])

# COMMAND ----------

pit_stop_df = spark.read \
.option('header',True) \
.schema(pit_stop_schema) \
.option("multiline",True) \
.json(f"{raw_folder_path}/pit_stops.json")

# COMMAND ----------

display(pit_stop_df)

# COMMAND ----------

pit_stop_renamed_df = pit_stop_df.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id") \
.withColumn("environment", lit(user_output_variable))

# COMMAND ----------

pit_stop_final_df = ingestion_date_column(pit_stop_renamed_df)

# COMMAND ----------

pit_stop_final_df.write.mode('overwrite').parquet(f"{processed_folder_path}/pit_stop")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/pit_stop"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")