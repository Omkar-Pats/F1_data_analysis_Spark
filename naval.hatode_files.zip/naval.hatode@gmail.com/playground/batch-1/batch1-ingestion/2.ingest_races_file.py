# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Assignment 1 to do transformation on races csv

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

## Define the schema Manually##

race_schema = StructType(fields = [StructField("raceId", IntegerType(), False),
                                    StructField("year", IntegerType(), True),
                                    StructField("round", IntegerType(), True),
                                    StructField("circuitId", IntegerType(), True),
                                    StructField("name", StringType(), True),
                                    StructField("date", StringType(), True),
                                    StructField("time", StringType(), True),
                                    StructField("url", StringType(), True)])

# COMMAND ----------

## read the races.csv file using manually created schema

races_df = spark.read.option("header", True).schema(race_schema).csv(f"{raw_folder_path}/races.csv")
#display(races_df)

# COMMAND ----------

## Rename the columns as required

races_renamed_df = races_df.withColumnRenamed ("raceid", "race_id") \
.withColumnRenamed("year", "race_year") \
.withColumnRenamed("circuitID", "circuit_Id") \
.withColumn("race_timestamp",to_timestamp(concat(col('date'), lit(' '), col('time')),'yyyy-MM-dd HH:mm:ss')) \
.withColumn("environment", lit(user_output_variable)) \
.drop ('url','date','time')

# COMMAND ----------

races_final_df = ingestion_date_column(races_renamed_df)

# COMMAND ----------

display(races_final_df)

# COMMAND ----------

## Re-write the file using Mode (Overwrite) and Do the partition by column race_year

races_final_df.write.mode("overwrite").partitionBy("race_year").parquet (f"{processed_folder_path}/races")

# COMMAND ----------

display(spark.read.parquet (f"{processed_folder_path}/races"))

# COMMAND ----------

dbutils.notebook.exit("Succefully Completed")