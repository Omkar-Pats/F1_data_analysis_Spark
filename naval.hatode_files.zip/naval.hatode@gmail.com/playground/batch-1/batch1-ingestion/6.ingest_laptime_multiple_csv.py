# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

laptime_schema = StructType (fields = [StructField("raceId",IntegerType(),False),
                                     StructField("driverId",IntegerType(),False),
                                     StructField("lap",IntegerType(),False),
                                     StructField("position",IntegerType(),False),
                                     StructField("time",StringType(),False),
                                     StructField("milliseconds",IntegerType(),False)])

# COMMAND ----------

laptime_df = spark.read \
.option("header",True) \
.schema(laptime_schema) \
.csv(f"{raw_folder_path}/lap_times/lap_time*")

# COMMAND ----------

laptime_remaned_df = laptime_df.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id") \
.withColumn("environment", lit(user_output_variable))

# COMMAND ----------

laptime_final_df = ingestion_date_column(laptime_remaned_df)

# COMMAND ----------

laptime_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/laptime")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/laptime"))

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")