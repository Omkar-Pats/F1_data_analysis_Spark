# Databricks notebook source
# MAGIC %md
# MAGIC # Ingets First CSV file

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula01dl/raw"))

# COMMAND ----------

circuits_df = spark.read.option('header',True).option("inferSchema",True).csv("/mnt/formula01dl/raw/circuits.csv")

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

circuits_df.describe().show()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType

# COMMAND ----------

cuircuit_schema = StructType(fields = [StructField("circuitId",IntegerType(),False),
                                      StructField("circuitRef",StringType(),True),
                                      StructField("name",StringType(),True),
                                      StructField("location",StringType(),True),
                                      StructField("country",StringType(),True),
                                      StructField("lat",DoubleType(),True),
                                      StructField("lng",DoubleType(),True),
                                      StructField("alt",DoubleType(),True),
                                      StructField("url",StringType(),True),])

# COMMAND ----------

circuits_df = spark.read \
.option('header',True) \
.schema(cuircuit_schema) \
.csv("/mnt/formula01dl/raw/circuits.csv")

# COMMAND ----------

display(circuits_df)