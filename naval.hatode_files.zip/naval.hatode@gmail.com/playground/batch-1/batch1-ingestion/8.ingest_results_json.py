# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("user_input","")
user_output_variable = dbutils.widgets.get("user_input")

# COMMAND ----------

# MAGIC %run "../includes/folder_path"

# COMMAND ----------

# MAGIC %run "../includes/all_functions"

# COMMAND ----------

results_schema = StructType (fields = [StructField("constructorId",IntegerType(),False),
                                      StructField("driverId",IntegerType(),False),
                                      StructField("fastestLap",StringType(),True),
                                      StructField("fastestLapSpeed",StringType(),True),
                                      StructField("fastestLapTime",StringType(),True),
                                      StructField("grid",IntegerType(),True),
                                      StructField("laps",IntegerType(),True),
                                      StructField("milliseconds",StringType(),True),
                                      StructField("number",StringType(),True),
                                      StructField("points",DoubleType(),True),
                                      StructField("position",StringType(),True),
                                      StructField("positionOrder",IntegerType(),True),
                                      StructField("raceId",IntegerType(),True),
                                      StructField("rank",StringType(),True),
                                      StructField("resultId",IntegerType(),True),
                                      StructField("statusId",IntegerType(),True),
                                      StructField("time",StringType(),True)])

# COMMAND ----------

results_df = spark.read \
.option('header', True) \
.schema(results_schema) \
.json(f'{raw_folder_path}/results.json')

# COMMAND ----------

results_renamed_df = results_df.withColumnRenamed("constructorId","constructor_id") \
.withColumnRenamed("driverId","driver_id") \
.withColumnRenamed("resultId","result_id") \
.withColumnRenamed("statusId","status_id") \
.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("fastestLap","fastest_lap") \
.withColumnRenamed("fastestLapSpeed","fastest_lap_speed") \
.withColumnRenamed("fastestLapTime","fastest_lap_time") \
.withColumn("environment", lit(user_output_variable))

# COMMAND ----------

result_fianl_df = ingestion_date_column(results_renamed_df)

# COMMAND ----------

result_fianl_df.write.mode("overwrite").parquet(f'{processed_folder_path}/results/')

# COMMAND ----------

dbutils.notebook.exit("Successfully Completed")