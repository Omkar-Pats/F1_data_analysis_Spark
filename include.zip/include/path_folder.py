# Databricks notebook source
raw_path_folder = '/mnt/formula01dl/omkar/Raw'
processed_path_folder = '/mnt/formula01dl/omkar/processed'
presentation_folder_path = '/mnt/formula01dl/omkar/presentation'

# COMMAND ----------

